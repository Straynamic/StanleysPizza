<?php
	$dbServername= "localhost";
	$dbUsername = "root";
	$dbPassword = "";
	$dbName="loginsystem";

	$conn = mysqli_connect($dbServername, $dbUsername, $dbPassword, $dbName);

?>