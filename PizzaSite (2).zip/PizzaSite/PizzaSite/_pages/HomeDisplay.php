﻿
<div class="ImagePromos">
	<link rel="stylesheet" type="text/css" href="../_css/PromoPictures.css">
	<div class="row">
		<div class="column">
		<a href = "../_pages/DeliveryType.php"><img class="PromoImg" id="promo3" src="../_images/pizza4.jpg"></a>
		</div>
		<div class="column">
		<a href = "../_pages/DeliveryType.php"><img class="PromoImg" id="promo1" src="../_images/pizza1.jpg"></a>
		<a href = "../_pages/DeliveryType.php"><img class="PromoImg" id="promo2" src="../_images/pizza2.jpg"></a>
		</div>
		<div class="across">
			<a href = "../_pages/Login.php"><img class="PromoImg" id="promo4" src="../_images/Banner1.png"></a>
		</div>



	</div>
</div>