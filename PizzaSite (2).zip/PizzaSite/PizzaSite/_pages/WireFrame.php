﻿<script src="../_javascript/HideElement.js"></script>
	
<button onclick="HE_ToggleHide()">Toggle Display</button>
<br><br>
<img id="HideableElement" src="../_images/WireFrame.png" style="display:none">