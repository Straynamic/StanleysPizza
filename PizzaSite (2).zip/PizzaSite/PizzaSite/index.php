<?php
//test
	session_start();
?>

<!DOCTYPE HTML>  
<html>
	<head>
		<link rel="stylesheet" type="text/css" href="_css/MainStyle.css">
		<title>Stanley's Pizzas</title>
	</head>

	<body>  
		<div class="myContainer">
			<?php include '_pages/NavBar.php';?>
			<?php include '_pages/HomeDisplay.php';?>

			<br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>

			<footer>
				<?php include '_pages/Footer.php';?>
			</footer>
		</div>
	</body>
	

</html>